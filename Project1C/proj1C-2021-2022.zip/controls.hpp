// Kikidis Konstantinos (4387)
// Tsampiras Konstantinos (4508)


#ifndef CONTROLS_HPP
#define CONTROLS_HPP
#define GLM_FORCE_SWIZZLE			// required for meteor to function properly
#define GLM_ENABLE_EXPERIMENTAL		// for #include <glm/gtx/string_cast.hpp>
void computeMatricesFromInputs();
glm::mat4 getViewMatrix();
glm::mat4 getProjectionMatrix();
glm::vec3 getPosition();

#endif