// Kikidis Konstantinos (4387)
// Tsampiras Konstantinos (4508)


// Include standard headers
#define _CRT_SECURE_NO_WARNINGS

#define STB_IMAGE_IMPLEMENTATION
#include <cmath> 
#include "stb_image.h"

#include <stdio.h>
#include <stdlib.h>
#include <vector>

#include <string>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <sstream>
using namespace std;

#include <stdlib.h>
#include <string.h>

#include <Windows.h>

// Include GLEW
#include <GL/glew.h>

// Include GLFW
#include <GLFW/glfw3.h>
GLFWwindow* window;

// Include GLM
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/string_cast.hpp>
using namespace glm;

#include "controls.hpp"
#include "objloader.hpp"

GLuint LoadShaders(const char* vertex_file_path, const char* fragment_file_path) {

	// Create the shaders
	GLuint VertexShaderID = glCreateShader(GL_VERTEX_SHADER);
	GLuint FragmentShaderID = glCreateShader(GL_FRAGMENT_SHADER);

	// Read the Vertex Shader code from the file
	std::string VertexShaderCode;
	std::ifstream VertexShaderStream(vertex_file_path, std::ios::in);
	if (VertexShaderStream.is_open()) {
		std::stringstream sstr;
		sstr << VertexShaderStream.rdbuf();
		VertexShaderCode = sstr.str();
		VertexShaderStream.close();
	}
	else {
		printf("Impossible to open %s. Are you in the right directory ? Don't forget to read the FAQ !\n", vertex_file_path);
		getchar();
		return 0;
	}

	// Read the Fragment Shader code from the file
	std::string FragmentShaderCode;
	std::ifstream FragmentShaderStream(fragment_file_path, std::ios::in);
	if (FragmentShaderStream.is_open()) {
		std::stringstream sstr;
		sstr << FragmentShaderStream.rdbuf();
		FragmentShaderCode = sstr.str();
		FragmentShaderStream.close();
	}

	GLint Result = GL_FALSE;
	int InfoLogLength;


	// Compile Vertex Shader
	printf("Compiling shader : %s\n", vertex_file_path);
	char const* VertexSourcePointer = VertexShaderCode.c_str();
	glShaderSource(VertexShaderID, 1, &VertexSourcePointer, NULL);
	glCompileShader(VertexShaderID);

	// Check Vertex Shader
	glGetShaderiv(VertexShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(VertexShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if (InfoLogLength > 0) {
		std::vector<char> VertexShaderErrorMessage(InfoLogLength + 1);
		glGetShaderInfoLog(VertexShaderID, InfoLogLength, NULL, &VertexShaderErrorMessage[0]);
		printf("%s\n", &VertexShaderErrorMessage[0]);
	}



	// Compile Fragment Shader
	printf("Compiling shader : %s\n", fragment_file_path);
	char const* FragmentSourcePointer = FragmentShaderCode.c_str();
	glShaderSource(FragmentShaderID, 1, &FragmentSourcePointer, NULL);
	glCompileShader(FragmentShaderID);

	// Check Fragment Shader
	glGetShaderiv(FragmentShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(FragmentShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if (InfoLogLength > 0) {
		std::vector<char> FragmentShaderErrorMessage(InfoLogLength + 1);
		glGetShaderInfoLog(FragmentShaderID, InfoLogLength, NULL, &FragmentShaderErrorMessage[0]);
		printf("%s\n", &FragmentShaderErrorMessage[0]);
	}



	// Link the program
	printf("Linking program\n");
	GLuint ProgramID = glCreateProgram();
	glAttachShader(ProgramID, VertexShaderID);
	glAttachShader(ProgramID, FragmentShaderID);
	glLinkProgram(ProgramID);

	// Check the program
	glGetProgramiv(ProgramID, GL_LINK_STATUS, &Result);
	glGetProgramiv(ProgramID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if (InfoLogLength > 0) {
		std::vector<char> ProgramErrorMessage(InfoLogLength + 1);
		glGetProgramInfoLog(ProgramID, InfoLogLength, NULL, &ProgramErrorMessage[0]);
		printf("%s\n", &ProgramErrorMessage[0]);
	}


	glDetachShader(ProgramID, VertexShaderID);
	glDetachShader(ProgramID, FragmentShaderID);

	glDeleteShader(VertexShaderID);
	glDeleteShader(FragmentShaderID);

	return ProgramID;
}



// Very, VERY simple OBJ loader.
// Here is a short list of features a real function would provide : 
// - Binary files. Reading a model should be just a few memcpy's away, not parsing a file at runtime. In short : OBJ is not very great.
// - Animations & bones (includes bones weights)
// - Multiple UVs
// - All attributes should be optional, not "forced"
// - More stable. Change a line in the OBJ file and it crashes.
// - More secure. Change another line and you can inject code.
// - Loading from memory, stream, etc

bool loadOBJ(
	const char* path,
	std::vector<glm::vec3>& out_vertices,
	std::vector<glm::vec2>& out_uvs,
	std::vector<glm::vec3>& out_normals
) {
	printf("Loading OBJ file %s...\n", path);

	std::vector<unsigned int> vertexIndices, uvIndices, normalIndices;
	std::vector<glm::vec3> temp_vertices;
	std::vector<glm::vec2> temp_uvs;
	std::vector<glm::vec3> temp_normals;


	FILE* file = fopen(path, "r");
	if (file == NULL) {
		printf("Impossible to open the file ! Are you in the right path ? See Tutorial 1 for details\n");
		getchar();
		return false;
	}

	while (1) {

		char lineHeader[128];
		// read the first word of the line
		int res = fscanf(file, "%s", lineHeader);
		if (res == EOF)
			break; // EOF = End Of File. Quit the loop.

		// else : parse lineHeader

		if (strcmp(lineHeader, "v") == 0) {
			glm::vec3 vertex;
			fscanf(file, "%f %f %f\n", &vertex.x, &vertex.y, &vertex.z);
			temp_vertices.push_back(vertex);
		}
		else if (strcmp(lineHeader, "vt") == 0) {
			glm::vec2 uv;
			fscanf(file, "%f %f\n", &uv.x, &uv.y);
			uv.y = -uv.y; // Invert V coordinate since we will only use DDS texture, which are inverted. Remove if you want to use TGA or BMP loaders.
			temp_uvs.push_back(uv);
		}
		else if (strcmp(lineHeader, "vn") == 0) {
			glm::vec3 normal;
			fscanf(file, "%f %f %f\n", &normal.x, &normal.y, &normal.z);
			temp_normals.push_back(normal);
		}
		else if (strcmp(lineHeader, "f") == 0) {
			std::string vertex1, vertex2, vertex3;
			unsigned int vertexIndex[3], uvIndex[3], normalIndex[3];
			int matches = fscanf(file, "%d/%d/%d %d/%d/%d %d/%d/%d\n", &vertexIndex[0], &uvIndex[0], &normalIndex[0], &vertexIndex[1], &uvIndex[1], &normalIndex[1], &vertexIndex[2], &uvIndex[2], &normalIndex[2]);
			if (matches != 9) {
				printf("File can't be read by our simple parser :-( Try exporting with other options\n");
				fclose(file);
				return false;
			}
			vertexIndices.push_back(vertexIndex[0]);
			vertexIndices.push_back(vertexIndex[1]);
			vertexIndices.push_back(vertexIndex[2]);
			uvIndices.push_back(uvIndex[0]);
			uvIndices.push_back(uvIndex[1]);
			uvIndices.push_back(uvIndex[2]);
			normalIndices.push_back(normalIndex[0]);
			normalIndices.push_back(normalIndex[1]);
			normalIndices.push_back(normalIndex[2]);
		}
		else {
			// Probably a comment, eat up the rest of the line
			char stupidBuffer[1000];
			fgets(stupidBuffer, 1000, file);
		}

	}


	while (1) {

		char lineHeader[128];
		// read the first word of the line
		int res2 = fscanf(file, "%s", lineHeader);
		if (res2 == EOF)
			break; // EOF = End Of File. Quit the loop.

		// else : parse lineHeader

		if (strcmp(lineHeader, "v") == 0) {
			glm::vec3 vertex;
			fscanf(file, "%f %f %f\n", &vertex.x, &vertex.y, &vertex.z);
			temp_vertices.push_back(vertex);
		}
		else if (strcmp(lineHeader, "vt") == 0) {
			glm::vec2 uv;
			fscanf(file, "%f %f\n", &uv.x, &uv.y);
			uv.y = -uv.y; // Invert V coordinate since we will only use DDS texture, which are inverted. Remove if you want to use TGA or BMP loaders.
			temp_uvs.push_back(uv);
		}
		else if (strcmp(lineHeader, "vn") == 0) {
			glm::vec3 normal;
			fscanf(file, "%f %f %f\n", &normal.x, &normal.y, &normal.z);
			temp_normals.push_back(normal);
		}
		else if (strcmp(lineHeader, "f") == 0) {
			std::string vertex1, vertex2, vertex3;
			unsigned int vertexIndex[3], uvIndex[3], normalIndex[3];
			int matches = fscanf(file, "%d/%d/%d %d/%d/%d %d/%d/%d\n", &vertexIndex[0], &uvIndex[0], &normalIndex[0], &vertexIndex[1], &uvIndex[1], &normalIndex[1], &vertexIndex[2], &uvIndex[2], &normalIndex[2]);
			if (matches != 9) {
				printf("File can't be read by our simple parser :-( Try exporting with other options\n");
				fclose(file);
				return false;
			}
			vertexIndices.push_back(vertexIndex[0]);
			vertexIndices.push_back(vertexIndex[1]);
			vertexIndices.push_back(vertexIndex[2]);
			uvIndices.push_back(uvIndex[0]);
			uvIndices.push_back(uvIndex[1]);
			uvIndices.push_back(uvIndex[2]);
			normalIndices.push_back(normalIndex[0]);
			normalIndices.push_back(normalIndex[1]);
			normalIndices.push_back(normalIndex[2]);
		}
		else {
			// Probably a comment, eat up the rest of the line
			char stupidBuffer[1000];
			fgets(stupidBuffer, 1000, file);
		}

	}
	// For each vertex of each triangle
	for (unsigned int i = 0; i < vertexIndices.size(); i++) {

		// Get the indices of its attributes
		unsigned int vertexIndex = vertexIndices[i];
		unsigned int uvIndex = uvIndices[i];
		unsigned int normalIndex = normalIndices[i];

		// Get the attributes thanks to the index
		glm::vec3 vertex = temp_vertices[vertexIndex - 1];
		glm::vec2 uv = temp_uvs[uvIndex - 1];
		glm::vec3 normal = temp_normals[normalIndex - 1];

		// Put the attributes in buffers
		out_vertices.push_back(vertex);
		out_uvs.push_back(uv);
		out_normals.push_back(normal);

	}
	fclose(file);
	return true;
}

int main(void)
{
	// Initialise GLFW
	if (!glfwInit())
	{
		fprintf(stderr, "Failed to initialize GLFW\n");
		getchar();
		return -1;
	}

	glfwWindowHint(GLFW_SAMPLES, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE); // To make MacOS happy; should not be needed
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// Open a window and create its OpenGL context
	window = glfwCreateWindow(800, 800, "Ηλιακό Σύστημα", NULL, NULL); ////
	if (window == NULL) {
		fprintf(stderr, "Failed to open GLFW window. If you have an Intel GPU, they are not 3.3 compatible. Try the 2.1 version of the tutorials.\n");
		getchar();
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);

	// Initialize GLEW
	glewExperimental = true; // Needed for core profile
	if (glewInit() != GLEW_OK) {
		fprintf(stderr, "Failed to initialize GLEW\n");
		getchar();
		glfwTerminate();
		return -1;
	}

	/*
	// Ensure we can capture the escape key being pressed below
	glfwSetInputMode(window, GLFW_STICKY_KEYS, GL_TRUE);
	// Hide the mouse and enable unlimited mouvement
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
	// Set the mouse at the center of the screen
	glfwPollEvents();
	glfwSetCursorPos(window, 1024/2, 768/2);
	*/
	// Black background
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);
	// Accept fragment if it closer to the camera than the former one
	glDepthFunc(GL_LESS);

	// Cull triangles which normal is not towards the camera
	glEnable(GL_CULL_FACE);

	GLuint VertexArrayID;
	glGenVertexArrays(1, &VertexArrayID);
	glBindVertexArray(VertexArrayID);

	// Create and compile our GLSL program from the shaders
	GLuint programID = LoadShaders("TransformVertexShader.vertexshader", "TextureFragmentShader.fragmentshader");

	// Get a handle for our "MVP" uniform
	GLuint MatrixID = glGetUniformLocation(programID, "MVP");

	// Load the textures
	int width, height, nrChannels;
	unsigned char* sunImage = stbi_load("sun.jpg", &width, &height, &nrChannels, 0);
	unsigned char* planetImage = stbi_load("planet.jpg", &width, &height, &nrChannels, 0);
	unsigned char* meteorImage = stbi_load("meteor.jpg", &width, &height, &nrChannels, 0);
	unsigned char* marsImage = stbi_load("mars.jpg", &width, &height, &nrChannels, 0); //BONUS

	if (sunImage && planetImage && meteorImage && marsImage)
	{

	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}

	// Generate Textures
	GLuint textureID[4];
	glGenTextures(4, textureID);
	GLuint TextureID = glGetUniformLocation(programID, "myTextureSampler");

	// Read .obj files
	std::vector<glm::vec3> verticesSun;
	std::vector<glm::vec3> normalsSun;
	std::vector<glm::vec2> uvsSun;
	bool resSun = loadOBJ("sun.obj", verticesSun, uvsSun, normalsSun);

	std::vector<glm::vec3> verticesPlanet;
	std::vector<glm::vec3> normalsPlanet;
	std::vector<glm::vec2> uvsPlanet;
	bool resPlanet = loadOBJ("planet.obj", verticesPlanet, uvsPlanet, normalsPlanet);

	std::vector<glm::vec3> verticesMeteor;
	std::vector<glm::vec3> normalsMeteor;
	std::vector<glm::vec2> uvsMeteor;
	bool resMeteor = loadOBJ("meteor.obj", verticesMeteor, uvsMeteor, normalsMeteor);

	std::vector<glm::vec3> verticesMars;
	std::vector<glm::vec3> normalsMars;
	std::vector<glm::vec2> uvsMars;
	bool resMars = loadOBJ("mars.obj", verticesMars, uvsMars, normalsMars);

	// Load it into a VBO

	GLuint vertexbuffer[4];
	glGenBuffers(4, vertexbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer[0]);
	glBufferData(GL_ARRAY_BUFFER, verticesSun.size() * sizeof(glm::vec3), &verticesSun[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer[1]); //
	glBufferData(GL_ARRAY_BUFFER, verticesPlanet.size() * sizeof(glm::vec3), &verticesPlanet[1], GL_STATIC_DRAW); //
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer[2]); //
	glBufferData(GL_ARRAY_BUFFER, verticesMeteor.size() * sizeof(glm::vec3), &verticesMeteor[2], GL_STATIC_DRAW); //
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer[3]); //
	glBufferData(GL_ARRAY_BUFFER, verticesMeteor.size() * sizeof(glm::vec3), &verticesMeteor[3], GL_STATIC_DRAW); //

	GLuint uvbuffer[4];
	glGenBuffers(4, uvbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, uvbuffer[0]);
	glBufferData(GL_ARRAY_BUFFER, uvsSun.size() * sizeof(glm::vec2), &uvsSun[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, uvbuffer[1]); //
	glBufferData(GL_ARRAY_BUFFER, uvsPlanet.size() * sizeof(glm::vec2), &uvsPlanet[1], GL_STATIC_DRAW); //
	glBindBuffer(GL_ARRAY_BUFFER, uvbuffer[2]); //
	glBufferData(GL_ARRAY_BUFFER, uvsMeteor.size() * sizeof(glm::vec2), &uvsMeteor[2], GL_STATIC_DRAW); //
	glBindBuffer(GL_ARRAY_BUFFER, uvbuffer[3]); //
	glBufferData(GL_ARRAY_BUFFER, uvsMeteor.size() * sizeof(glm::vec2), &uvsMeteor[3], GL_STATIC_DRAW); //

	// For Planet Rotation
	double x = 25.0f;
	double z = 0.0f;
	double angle = 0.0f;
	// For Mars Rotation (BONUS)
	double x2 = -50.0f;
	double z2 = 0.0f;
	double angle2 = 0.0f;

	// Flags
	bool meteorInit = true;
	bool meteorActivate = false;
	bool planetCollision = false;
	// Meteor Position Values and Step Size for each axis
	float meteorXPos, meteorYPos, meteorZPos;
	float stepX, stepY, stepZ;
	// Initial Planet Rotation Speed
	double speed = 0.05f;

	do {

		// Clear the screen
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Use our shader
		glUseProgram(programID);

		// Compute the MVP matrix from keyboard input
		computeMatricesFromInputs();
		glm::mat4 ProjectionMatrix = getProjectionMatrix();
		glm::mat4 ViewMatrix = getViewMatrix();

		// Sun MVP
		glm::mat4 ModelMatrixSun = glm::mat4(1.0);
		glm::mat4 SunMVP = ProjectionMatrix * ViewMatrix * ModelMatrixSun;

		// Planet MVP
		glm::mat4 ModelMatrixPlanet = glm::mat4(1.0); 
		ModelMatrixPlanet = glm::translate(ModelMatrixPlanet, glm::vec3(x, 0.0f, z));
		glm::mat4 PlanetMVP = ProjectionMatrix * ViewMatrix * ModelMatrixPlanet;

		// Mars MVP (BONUS)
		glm::mat4 ModelMatrixMars = glm::mat4(1.0);//
		ModelMatrixMars = glm::translate(ModelMatrixMars, glm::vec3(x2, 0.0f, z2));
		ModelMatrixMars = glm::scale(ModelMatrixMars, glm::vec3(3.0f, 3.0f, 3.0f));
		glm::mat4 MarsMVP = ProjectionMatrix * ViewMatrix * ModelMatrixMars;

		// Planet rotation around Sun (circular orbit)
		double radius = 25.0f;
		x = radius * sin(3.14 * 2 * angle / 360);
		z = radius * cos(3.14 * 2 * angle / 360);
		glm::vec3 planetPos = glm::vec3(x, 0.0f, z);
		ModelMatrixPlanet = glm::translate(ModelMatrixPlanet, planetPos);
		
		// BONUS: Change Planet Rotation Speed
		if (glfwGetKey(window, GLFW_KEY_U) == GLFW_PRESS) {
			speed += 0.001f; // If "u" pressed, increase rotating speed
		}
		if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
			speed -= 0.001f; // If "p" pressed, decrease rotating speed
		}
		angle += speed;

		// Mars Rotation around Sun (BONUS)
		double radiusMars = -50.0f;
		x2 = radiusMars * sin(3.14 * 2 * angle2 / 360);
		z2 = radiusMars * cos(3.14 * 2 * angle2 / 360);
		glm::vec3 marsPos = glm::vec3(x2, 0.0f, z2);
		ModelMatrixMars = glm::translate(ModelMatrixMars, marsPos);
		angle2 += 0.05f;

		// Meteor MVP
		glm::mat4 ModelMatrixMeteor = glm::mat4(1.0); //

		// Detect if Spacebar has been pressed, then activate Meteor
		if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS) {
			meteorActivate = true;
		}
		
		// Meteor is activated
		if (meteorActivate) {
			if (planetCollision) {  // Check if we had a collision already, then disable meteor
				meteorActivate = false;
			}

			if (meteorInit) { // Initialize Meteor starting position, run once when spacebar pressed
				glm::vec3 camPos = getPosition(); 
				meteorXPos = camPos.x;
				meteorYPos = camPos.y;
				meteorZPos = camPos.z;
				std::cout << "DEBUG ::: Meteor Starting Position: " + glm::to_string(glm::vec3(meteorXPos, meteorYPos, meteorZPos)) + "\n"; // Print meteor starting position 
				ModelMatrixMeteor = glm::translate(ModelMatrixMeteor, glm::vec3(meteorXPos,meteorYPos,meteorZPos));
				meteorInit = false; // Disable this "if" block after running once
				int stepFactor = 2500; // Step Factor, to make meteor go faster towards sun, lower this value, to go slower towards sun, increase this value
				stepX = meteorXPos / stepFactor; 
				stepY = meteorYPos / stepFactor;
				stepZ = meteorZPos / stepFactor;
			}
			meteorXPos -= stepX; // Change meteor position, go towards sun (0,0,0)
			meteorYPos -= stepY;
			meteorZPos -= stepZ;
			glm::vec3 meteorPos = glm::vec3(meteorXPos, meteorYPos, meteorZPos);
			ModelMatrixMeteor = glm::translate(ModelMatrixMeteor, meteorPos); 
			glm::mat4 MeteorMVP = ProjectionMatrix * ViewMatrix * ModelMatrixMeteor;
			std::cout << "DEBUG ::: Meteor Position: " + glm::to_string(glm::vec3(meteorXPos, meteorYPos, meteorZPos)) +"\n"; // Print meteor position 

			// If the meteor is inside the sun (very close to the center), then we disable it 
			if (meteorXPos < 1.0f && meteorYPos < 1.0f && meteorZPos < 1.0f) {
				meteorActivate = false; // Disable Meteor
				stepX = 0; // don't move it again
				stepY = 0;
				stepZ = 0;
			}

			// Finds the distance between the Planet and the Meteor, d(meteor_2-planet_1) = square_root((x2-x1)^2+(y2-y1)^2+(z2-z1)^2)
			double distanceMeteorPlanetCenters = sqrt((pow((meteorPos.x - planetPos.x), 2.0f)) + (pow((meteorPos.y - planetPos.y), 2.0f)) + (pow((meteorPos.z - planetPos.z), 2.0f)));
			if (distanceMeteorPlanetCenters < 7) { // If distace is <7 (radiusPlanet=5 and radiusMeteor=2), then we have a collision
				meteorActivate = false; // Disable Meteor 
				planetCollision = true; // Enable Collision Flag
				stepX = 0; // don't move it again
				stepY = 0;
				stepZ = 0;
				printf("\nDEBUG ::: Meteor and Planet Collided\n\n");
			}

			// If Meteor is Active, Draw Meteor
			if (meteorActivate) {
				glUniformMatrix4fv(MatrixID, 1, GL_FALSE, &MeteorMVP[0][0]);
				glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, meteorImage);
				glGenerateMipmap(GL_TEXTURE_2D);
				glActiveTexture(GL_TEXTURE2);
				glBindTexture(GL_TEXTURE_2D, textureID[1]); // Weird behavior. With textureID[2], we had problems, by trying textureID[1], it worked fine
				glUniform1i(TextureID, 2); 

				// 1rst attribute buffer : vertices
				glEnableVertexAttribArray(0);
				glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer[2]);
				glVertexAttribPointer(
					0,                  // attribute
					3,                  // size
					GL_FLOAT,           // type
					GL_FALSE,           // normalized?
					0,                  // stride
					(void*)0            // array buffer offset
				);

				// 2nd attribute buffer : UVs
				glEnableVertexAttribArray(1);
				glBindBuffer(GL_ARRAY_BUFFER, uvbuffer[2]);
				glVertexAttribPointer(
					1,                                // attribute
					2,                                // size 
					GL_FLOAT,                         // type
					GL_FALSE,                         // normalized?
					0,                                // stride
					(void*)0                          // array buffer offset
				);

				glDrawArrays(GL_TRIANGLES, 0, verticesMeteor.size());
			}
		}

		////////

		// Draw Sun
		glUniformMatrix4fv(MatrixID, 1, GL_FALSE, &SunMVP[0][0]);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, sunImage);
		glGenerateMipmap(GL_TEXTURE_2D);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, textureID[1]); // Weird behavior. With textureID[0], we had problems, by trying textureID[1], it worked fine
		glUniform1i(TextureID, 0);

		// 1rst attribute buffer : vertices
		glEnableVertexAttribArray(0);
		glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer[0]);
		glVertexAttribPointer(
			0,                  // attribute
			3,                  // size
			GL_FLOAT,           // type
			GL_FALSE,           // normalized?
			0,                  // stride
			(void*)0            // array buffer offset
		);

		// 2nd attribute buffer : UVs
		glEnableVertexAttribArray(1);
		glBindBuffer(GL_ARRAY_BUFFER, uvbuffer[0]);
		glVertexAttribPointer(
			1,                                // attribute
			2,                                // size 
			GL_FLOAT,                         // type
			GL_FALSE,                         // normalized?
			0,                                // stride
			(void*)0                          // array buffer offset
		);

		glDrawArrays(GL_TRIANGLES, 0, verticesSun.size());

		////////

		// Draw Planet
		if (planetCollision) { // Check if we had a collision, if we had, we zero-out the PlanetMVP matrix, effectively disabling it
			PlanetMVP = glm::mat4(0.0f);
		} 
		glUniformMatrix4fv(MatrixID, 1, GL_FALSE, &PlanetMVP[0][0]);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, planetImage); 
		glGenerateMipmap(GL_TEXTURE_2D); 
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, textureID[1]);
		glUniform1i(TextureID, 1);

		// 1rst attribute buffer : vertices
		glEnableVertexAttribArray(0);
		glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer[1]);
		glVertexAttribPointer(
			0,                  // attribute
			3,                  // size
			GL_FLOAT,           // type
			GL_FALSE,           // normalized?
			0,                  // stride
			(void*)0            // array buffer offset
		);

		// 2nd attribute buffer : UVs
		glEnableVertexAttribArray(1);
		glBindBuffer(GL_ARRAY_BUFFER, uvbuffer[1]);
		glVertexAttribPointer(
			1,                                // attribute
			2,                                // size
			GL_FLOAT,                         // type
			GL_FALSE,                         // normalized?
			0,                                // stride
			(void*)0                          // array buffer offset
		);

		glDrawArrays(GL_TRIANGLES, 0, verticesPlanet.size());
		
		////////

		// Draw Mars (BONUS)
		glUniformMatrix4fv(MatrixID, 1, GL_FALSE, &MarsMVP[0][0]);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, marsImage);
		glGenerateMipmap(GL_TEXTURE_2D);
		glActiveTexture(GL_TEXTURE3);
		glBindTexture(GL_TEXTURE_2D, textureID[1]);
		glUniform1i(TextureID, 3);

		// 1rst attribute buffer : vertices
		glEnableVertexAttribArray(0);
		glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer[3]);
		glVertexAttribPointer(
			0,                  // attribute
			3,                  // size
			GL_FLOAT,           // type
			GL_FALSE,           // normalized?
			0,                  // stride
			(void*)0            // array buffer offset
		);

		// 2nd attribute buffer : UVs
		glEnableVertexAttribArray(1);
		glBindBuffer(GL_ARRAY_BUFFER, uvbuffer[3]);
		glVertexAttribPointer(
			1,                                // attribute
			2,                                // size
			GL_FLOAT,                         // type
			GL_FALSE,                         // normalized?
			0,                                // stride
			(void*)0                          // array buffer offset
		);

		glDrawArrays(GL_TRIANGLES, 0, verticesMars.size());

		////////

		glDisableVertexAttribArray(0);
		glDisableVertexAttribArray(1);

		// Swap buffers
		glfwSwapBuffers(window);
		glfwPollEvents();
		
	} // Check if the Q key was pressed or the window was closed
	while ((!(GetKeyState('Q') & 0x8000) || (!(GetKeyState(VK_SHIFT) & 0x8000) ^ (GetKeyState(VK_CAPITAL) & 1))) &&			////
		glfwWindowShouldClose(window) == 0);

	// Cleanup VBO and shader
	glDeleteBuffers(4, vertexbuffer);
	glDeleteBuffers(4, uvbuffer);
	glDeleteProgram(programID);
	glDeleteTextures(4, textureID);
	glDeleteVertexArrays(1, &VertexArrayID);

	// Close OpenGL window and terminate GLFW
	glfwTerminate();

	return 0;
}

